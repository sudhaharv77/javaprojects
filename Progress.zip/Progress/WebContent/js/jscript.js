var endpoints = {"buttons":[7,22,-17,-39],"bars":[64,87,10],"limit":150}
function updateProgress(value) {
	var progressType = document.getElementById("progress_type");
	if(progressType.value=="progress1"){
		updateProgressBarWidth("progress_bar_1",value,"progress_bar_1_text");
	}else if(progressType.value=="progress2"){
		updateProgressBarWidth("progress_bar_2",value,"progress_bar_2_text");
	}else if(progressType.value=="progress3"){
		updateProgressBarWidth("progress_bar_3",value,"progress_bar_3_text");
	}
	//alert(progressType.value);
    //alert("You have selected some text! "+value);

}
function updateProgressBarWidth( progressBarId, newBarWidth,pctTextDivId) {
	if(null == progressBarId){
		return;
	}
    var elem = document.getElementById(progressBarId);
	var width = 0;
	if(newBarWidth<0){
		width = 0;
	}
    
    var id = setInterval(frame, 10);
    function frame() {
        if (width >= 100|| width==newBarWidth) {
			console.log("progress bar width update has finished : "+width);
            clearInterval(id);
        } else {
			
			var percentageIndex = elem.style.width.indexOf("%");
			var currentWidth = elem.style.width.substr(0,elem.style.width.indexOf("%"))
			if(currentWidth>=parseInt(endpoints.limit)){
				elem.style.backgroundColor="Red"
			}
			if(newBarWidth>0){
				width++;
				elem.style.width = (parseInt(currentWidth)+1)+ '%'; 
				document.getElementById(pctTextDivId).innerText=elem.style.width;
			}else{
				width--;
				elem.style.width = (parseInt(currentWidth)-1)+ '%';
				document.getElementById(pctTextDivId).innerText=elem.style.width;
			}
            
			 
			
            
			console.log("updated width size "+width);
        }
    }
}
function setData(){
	for(var i=0;i<endpoints.buttons.length;i++){
		document.getElementById("btn_"+i).value = endpoints.buttons[i];
	}
	for(var j=0;j<endpoints.bars.length;j++){
		document.getElementById("progress_bar_"+(j+1)).value = endpoints.bars[j];
		document.getElementById("progress_bar_"+(j+1)).style.width = endpoints.bars[j]+"%";
		document.getElementById("progress_bar_"+(j+1)+"_text").innerText = endpoints.bars[j]+"%";
		
	}
	
	
}
